#include<iostream>
#include<cmath>
using namespace std;

int main() {
    int n, m = 0, exp = 0;
    int a[1000] = {0};
    cin >> n;
    //for(int i = 0; i < n; i++)
    //    cin >> a[i];
    while(1) {
        if(n <= pow(2, exp))
            break;
        else exp++;
    }
    cout << exp;
}
