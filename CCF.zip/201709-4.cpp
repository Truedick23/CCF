#include<iostream>
using namespace std;

const int TRUE = 1;
const int FALSE = 0;

int route[100][100];

int main() {
    int m, n, num = 0;
    cin >> n >> m;
    for(int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        route[a][b] = TRUE;
        route[b][a] = TRUE;
        for(int j = 0; j < m; i++) {
            if(route[j][a]) {
                route[j][b] = TRUE;
                route[b][j] = TRUE;
            }
            if(route[j][b]) {
                route[j][a] = TRUE;
                route[a][j] = TRUE;
            }
        }
    }
    for(int i = 0; i < n; i++) {
        bool flag = true;
        for(int j = 0; j < n; j++)
            if(route[i][j] == 0)
                flag = false;
        if(flag) num++;
    }
    cout << num;
    return 0;
}
