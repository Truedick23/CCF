#include<iostream>
using namespace std;

bool proceed(int times[], int n) {
    bool ok = false;
    for(int i = 0; i < n; i++)
        if(times[i] != 0)
            ok = false;
    return ok;
}

int main() {
    int n;
    int times[1000] = {0}, maxi = 0;
    cin >> n;
    for(int i = 0; i < n; i++) {
        int num;
        cin >> num;
        times[num]++;
    }
    while(1) {
        maxi = 0;
        for(int i = 0; i < n; i++) {
            if(times[i] > maxi)
                maxi = times[i];
        }
        if(maxi == 0)
            break;
        for(int i = 0; i < n; i++) {
            if(times[i] == maxi) {
                cout << i << " " << maxi << endl;
                times[i] = 0;
            }
        }
    }
    return 0;
}
